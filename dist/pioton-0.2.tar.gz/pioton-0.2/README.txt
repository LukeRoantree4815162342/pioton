# Píotón - Write Python code in Irish in IPython

---
#### USAGE
simply import píotón in any IPython environment (including Jupyter Notebooks) and start writing your code as Gaeilge.
Call `pioton.show_syntax() ` to print a full description of the new irish syntax.

#### THIS IS FOR FUN - DO NOT USE THIS FOR ANYTHING IMPORTANT
I can't stress that enough, I really didn't make sure it's robust at all, it's against Python standards, any code written in it will be completely unmaintainable, etc.

---

##### How it all works:
píotón parses the IPython input into 'real' python, then sends that on to the python kernel. As a result of this approach, writing standard python instead / as well is also completely fine 
